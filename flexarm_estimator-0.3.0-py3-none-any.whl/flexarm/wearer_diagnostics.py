from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping, Sequence

import numpy as np
import pandas as pd


ACTIONS = ("Forward", "Lateral", "Backward")
STAGES = ("low", "high")
NORMALIZED_COLUMNS = (
    "flex1_change_normalized",
    "flex2_change_normalized",
    "flex3_change_normalized",
)
REQUIRED_TRAINING_COLUMNS = ("action_label", "angle_deg", *NORMALIZED_COLUMNS)


Vec3 = tuple[float, float, float]


@dataclass(frozen=True)
class StageReference:
    median: Vec3
    p10: Vec3
    p90: Vec3
    iqr: Vec3
    sample_count: int


def _vec3(values: np.ndarray) -> Vec3:
    return tuple(float(value) for value in values)  # type: ignore[return-value]


def _angle_mask(action: str, stage: str, angles: np.ndarray) -> np.ndarray:
    if stage == "low":
        return (angles >= 20.0) & (angles < 40.0)
    high_minimum = 40.0 if action == "Backward" else 60.0
    return angles >= high_minimum


def build_training_references(
    frame: pd.DataFrame,
) -> dict[str, dict[str, StageReference]]:
    missing = [column for column in REQUIRED_TRAINING_COLUMNS if column not in frame.columns]
    if missing:
        raise ValueError(f"missing training columns: {', '.join(missing)}")
    if frame.empty:
        raise ValueError("training data is empty")

    numeric = frame.loc[:, ("angle_deg", *NORMALIZED_COLUMNS)].apply(
        pd.to_numeric, errors="coerce"
    )
    if not np.isfinite(numeric.to_numpy(dtype=float)).all():
        raise ValueError("training data contains non-finite numeric values")

    labels = frame["action_label"].astype(str)
    angles = numeric["angle_deg"].to_numpy(dtype=float)
    features = numeric.loc[:, NORMALIZED_COLUMNS].to_numpy(dtype=float)
    references: dict[str, dict[str, StageReference]] = {}
    for action in ACTIONS:
        references[action] = {}
        action_mask = labels.to_numpy() == action
        for stage in STAGES:
            selected = features[action_mask & _angle_mask(action, stage, angles)]
            if len(selected) == 0:
                raise ValueError(f"empty training reference for {action}/{stage}")
            references[action][stage] = StageReference(
                median=_vec3(np.median(selected, axis=0)),
                p10=_vec3(np.quantile(selected, 0.10, axis=0)),
                p90=_vec3(np.quantile(selected, 0.90, axis=0)),
                iqr=_vec3(
                    np.quantile(selected, 0.75, axis=0)
                    - np.quantile(selected, 0.25, axis=0)
                ),
                sample_count=int(len(selected)),
            )
    return references


def normalize_samples(
    raw_samples: Sequence[Sequence[float]],
    baseline: Sequence[float],
    scale: Sequence[float],
) -> np.ndarray:
    samples = np.asarray(raw_samples, dtype=float)
    baseline_values = np.asarray(baseline, dtype=float)
    scale_values = np.asarray(scale, dtype=float)
    if samples.ndim != 2 or samples.shape[1:] != (3,) or samples.shape[0] == 0:
        raise ValueError("raw samples must have shape (n, 3) with n >= 1")
    if baseline_values.shape != (3,) or not np.isfinite(baseline_values).all():
        raise ValueError("baseline must contain three finite values")
    if (
        scale_values.shape != (3,)
        or not np.isfinite(scale_values).all()
        or np.any(scale_values <= 0.0)
    ):
        raise ValueError("scale must contain three finite positive values")
    if not np.isfinite(samples).all():
        raise ValueError("raw samples must contain only finite values")
    return (samples - baseline_values) / scale_values


def _matrix(values: Sequence[Sequence[float]], *, name: str) -> np.ndarray:
    matrix = np.asarray(values, dtype=float)
    if matrix.ndim != 2 or matrix.shape[1:] != (3,) or matrix.shape[0] == 0:
        raise ValueError(f"{name} must have shape (n, 3) with n >= 1")
    if not np.isfinite(matrix).all():
        raise ValueError(f"{name} must contain only finite values")
    return matrix


def _sign(values: np.ndarray, deadband: float = 0.05) -> np.ndarray:
    return np.where(values > deadband, 1, np.where(values < -deadband, -1, 0))


def diagnose_stage(
    planned_action: str,
    stage: str,
    normalized_samples: Sequence[Sequence[float]],
    references: Mapping[str, Mapping[str, StageReference]],
) -> dict[str, object]:
    if planned_action not in ACTIONS:
        raise ValueError(f"unsupported planned action: {planned_action}")
    if stage not in STAGES:
        raise ValueError(f"unsupported angle stage: {stage}")
    samples = _matrix(normalized_samples, name="normalized samples")
    try:
        target = references[planned_action][stage]
        stage_references = {action: references[action][stage] for action in ACTIONS}
    except KeyError as exc:
        raise ValueError(f"missing training reference: {exc.args[0]}") from exc

    current = np.median(samples, axis=0)
    current_sign = _sign(current)
    target_median = np.asarray(target.median, dtype=float)
    target_sign = _sign(target_median)
    direction_matches = int(np.sum(current_sign == target_sign))
    opposite_channels = [
        index + 1
        for index, (actual, expected) in enumerate(zip(current_sign, target_sign))
        if actual * expected == -1
    ]
    near_zero_channels = [
        index + 1
        for index, (actual, expected) in enumerate(zip(current_sign, target_sign))
        if actual == 0 or expected == 0
    ]

    lower = np.asarray(target.p10, dtype=float) - 0.10
    upper = np.asarray(target.p90, dtype=float) + 0.10
    out_of_range_channels = [
        index + 1
        for index, value in enumerate(current)
        if value < lower[index] or value > upper[index]
    ]

    distances: dict[str, float] = {}
    for action, reference in stage_references.items():
        center = np.asarray(reference.median, dtype=float)
        width = np.maximum(np.asarray(reference.iqr, dtype=float), 0.10)
        distances[action] = float(np.mean(np.abs(current - center) / width))
    ordered = sorted(distances.items(), key=lambda item: (item[1], ACTIONS.index(item[0])))
    nearest_action, nearest_distance = ordered[0]
    runner_up_action, runner_up_distance = ordered[1]
    ambiguous = (
        runner_up_distance - nearest_distance
    ) / max(runner_up_distance, 1e-12) < 0.10

    if (
        nearest_action != planned_action
        or len(opposite_channels) >= 2
        or len(out_of_range_channels) >= 2
    ):
        risk = "HIGH"
    elif (
        len(opposite_channels) == 1
        or len(out_of_range_channels) == 1
        or direction_matches < 2
        or ambiguous
    ):
        risk = "MEDIUM"
    else:
        risk = "LOW"

    return {
        "planned_action": planned_action,
        "angle_stage": stage,
        "sample_count": int(len(samples)),
        "current_median": list(_vec3(current)),
        "training_median": list(target.median),
        "training_p10": list(target.p10),
        "training_p90": list(target.p90),
        "direction_matches": direction_matches,
        "opposite_channels": opposite_channels,
        "near_zero_channels": near_zero_channels,
        "out_of_range_channels": out_of_range_channels,
        "distances": distances,
        "nearest_action": nearest_action,
        "nearest_distance": nearest_distance,
        "runner_up_action": runner_up_action,
        "runner_up_distance": runner_up_distance,
        "ambiguous": bool(ambiguous),
        "risk": risk,
    }


def diagnose_baseline_drift(
    start_rest: Sequence[Sequence[float]],
    end_rest: Sequence[Sequence[float]],
    scale: Sequence[float],
) -> dict[str, object]:
    start = _matrix(start_rest, name="start rest")
    end = _matrix(end_rest, name="end rest")
    scale_values = np.asarray(scale, dtype=float)
    if (
        scale_values.shape != (3,)
        or not np.isfinite(scale_values).all()
        or np.any(scale_values <= 0.0)
    ):
        raise ValueError("scale must contain three finite positive values")
    start_median = np.median(start, axis=0)
    end_median = np.median(end, axis=0)
    drift = np.abs(end_median - start_median) / scale_values
    status = [
        "STABLE" if value <= 0.05 else "WARNING" if value <= 0.15 else "LARGE"
        for value in drift
    ]
    return {
        "start_baseline": list(_vec3(start_median)),
        "end_baseline": list(_vec3(end_median)),
        "normalized_drift": list(_vec3(drift)),
        "channel_status": status,
    }


def diagnose_channel_health(
    samples: Sequence[Sequence[float]],
    *,
    adc_min: float = 0.0,
    adc_max: float = 4095.0,
    minimum_motion_range: float = 5.0,
) -> list[dict[str, object]]:
    values = _matrix(samples, name="raw motion samples")
    results: list[dict[str, object]] = []
    for index in range(3):
        channel = values[:, index]
        minimum = float(np.min(channel))
        maximum = float(np.max(channel))
        median = float(np.median(channel))
        channel_range = maximum - minimum
        if channel_range <= 1e-9 and median <= adc_min + 1.0:
            status = "SATURATED_LOW"
        elif channel_range <= 1e-9 and median >= adc_max - 1.0:
            status = "SATURATED_HIGH"
        elif channel_range <= 1e-9:
            status = "CONSTANT"
        elif channel_range < minimum_motion_range:
            status = "TOO_SMALL"
        else:
            status = "OK"
        results.append(
            {
                "channel": index + 1,
                "packet_field_position": index + 3,
                "status": status,
                "min": minimum,
                "median": median,
                "max": maximum,
                "range": channel_range,
            }
        )
    return results


def summarize_wearer_shift(
    stage_results: Sequence[Mapping[str, object]],
    drift: Mapping[str, object],
    channel_health: Sequence[Mapping[str, object]],
) -> dict[str, object]:
    results = [dict(result) for result in stage_results]
    failed_channels = [
        dict(item) for item in channel_health if str(item.get("status")) != "OK"
    ]
    if failed_channels:
        conclusion = "HARDWARE CHECK REQUIRED"
    else:
        high_angle_high = sum(
            result.get("angle_stage") == "high" and result.get("risk") == "HIGH"
            for result in results
        )
        medium_count = sum(result.get("risk") == "MEDIUM" for result in results)
        if high_angle_high >= 2:
            conclusion = "HIGH wearer/placement shift"
        elif high_angle_high == 1 or medium_count >= 2:
            conclusion = "MEDIUM wearer/placement shift"
        else:
            conclusion = "LOW wearer/placement shift"
    return {
        "overall_conclusion": conclusion,
        "stage_results": results,
        "baseline_drift": dict(drift),
        "channel_health": [dict(item) for item in channel_health],
        "failed_channels": failed_channels,
        "interpretation": (
            "This run detects mismatch with the training domain; it cannot uniquely "
            "separate anatomy differences from garment movement."
        ),
    }


def _format_vector(values: object) -> str:
    if not isinstance(values, Sequence):
        return "[]"
    return "[" + ", ".join(f"{float(value):+.3f}" for value in values) + "]"


def format_diagnostic_report(diagnosis: Mapping[str, object]) -> str:
    lines = [
        "跨人 / 袖套穿戴偏移诊断",
        "=" * 38,
        f"总体结论 / Overall: {diagnosis.get('overall_conclusion', 'UNKNOWN')}",
        "",
    ]
    for result in diagnosis.get("stage_results", []):
        item = dict(result)
        lines.extend(
            [
                f"{item['planned_action']} / {item['angle_stage']}",
                f"  当前中位值: {_format_vector(item.get('current_median'))}",
                f"  训练中位值: {_format_vector(item.get('training_median'))}",
                f"  最近动作:   {item.get('nearest_action')}",
                f"  反向通道:   {item.get('opposite_channels', [])}",
                f"  越界通道:   {item.get('out_of_range_channels', [])}",
                f"  风险等级:   {item.get('risk')}",
                "",
            ]
        )
    drift = dict(diagnosis.get("baseline_drift", {}))
    lines.extend(
        [
            "基线漂移",
            f"  归一化漂移: {_format_vector(drift.get('normalized_drift', []))}",
            f"  通道状态:   {drift.get('channel_status', [])}",
            "",
            "通道健康",
        ]
    )
    for item in diagnosis.get("channel_health", []):
        channel = dict(item)
        lines.append(
            f"  Flex{channel.get('channel')} (packet field "
            f"{channel.get('packet_field_position', '?')}): {channel.get('status')}"
        )
    lines.extend(["", str(diagnosis.get("interpretation", "")), ""])
    return "\n".join(lines)
