from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Iterable

import numpy as np


Quaternion = Iterable[float]


def _unit_vector(value: Iterable[float], name: str) -> np.ndarray:
    vector = np.asarray(tuple(value), dtype=float)
    if vector.shape != (3,) or not np.isfinite(vector).all():
        raise ValueError(f"{name} must be a finite 3-vector")
    norm = float(np.linalg.norm(vector))
    if norm < 1e-12:
        raise ValueError(f"{name} cannot be zero")
    return vector / norm


def _normalize_quaternion(value: Quaternion) -> np.ndarray:
    quaternion = np.asarray(tuple(value), dtype=float)
    if quaternion.shape != (4,) or not np.isfinite(quaternion).all():
        raise ValueError("quaternion must contain four finite values [w,x,y,z]")
    norm = float(np.linalg.norm(quaternion))
    if norm < 1e-12:
        raise ValueError("quaternion cannot be zero")
    return quaternion / norm


def _multiply(left: Quaternion, right: Quaternion) -> np.ndarray:
    w1, x1, y1, z1 = _normalize_quaternion(left)
    w2, x2, y2, z2 = _normalize_quaternion(right)
    return _normalize_quaternion((
        w1 * w2 - x1 * x2 - y1 * y2 - z1 * z2,
        w1 * x2 + x1 * w2 + y1 * z2 - z1 * y2,
        w1 * y2 - x1 * z2 + y1 * w2 + z1 * x2,
        w1 * z2 + x1 * y2 - y1 * x2 + z1 * w2,
    ))


def _conjugate(value: Quaternion) -> np.ndarray:
    w, x, y, z = _normalize_quaternion(value)
    return np.asarray((w, -x, -y, -z), dtype=float)


def _relative(chest: Quaternion, arm: Quaternion) -> np.ndarray:
    return _multiply(_conjugate(chest), arm)


def _rotate(quaternion: Quaternion, vector: Iterable[float]) -> np.ndarray:
    q = _normalize_quaternion(quaternion)
    v = np.asarray(tuple(vector), dtype=float)
    qv = q[1:]
    cross = 2.0 * np.cross(qv, v)
    return v + q[0] * cross + np.cross(qv, cross)


def _samples(value: Iterable[Quaternion] | Quaternion) -> list[np.ndarray]:
    materialized = list(value)
    if len(materialized) == 4 and all(np.isscalar(item) for item in materialized):
        return [_normalize_quaternion(materialized)]
    return [_normalize_quaternion(item) for item in materialized]


def _mean_quaternion(values: Iterable[Quaternion]) -> np.ndarray:
    quaternions = [_normalize_quaternion(value) for value in values]
    if not quaternions:
        raise ValueError("at least one quaternion sample is required")
    reference = quaternions[0]
    aligned = [value if float(np.dot(value, reference)) >= 0.0 else -value for value in quaternions]
    return _normalize_quaternion(np.mean(aligned, axis=0))


@dataclass(frozen=True, slots=True)
class DualImuCalibration:
    chest_reference: tuple[float, float, float, float]
    arm_reference: tuple[float, float, float, float]
    relative_reference: tuple[float, float, float, float]
    sample_count: int


@dataclass(frozen=True, slots=True)
class DirectionCalibration:
    forward_axis: tuple[float, float, float]
    lateral_axis: tuple[float, float, float]
    representative_magnitude_deg: float
    sample_count: int


@dataclass(frozen=True, slots=True)
class ArmRaiseEstimate:
    direction: str
    magnitude_deg: float
    plane_deg: float
    confidence: float
    forward_component: float
    lateral_component: float
    arm_vector: tuple[float, float, float]

    @property
    def angle_deg(self) -> float:
        """Alias for ``magnitude_deg``."""
        return self.magnitude_deg


class DualImuArmEstimator:
    """Estimate arm-raise direction and magnitude from chest and arm IMUs.

    Quaternions use ``[w, x, y, z]`` and must describe sensor-local to world
    orientation. Call :meth:`calibrate` while the arm is naturally hanging
    before calling :meth:`estimate`.
    """

    def __init__(
        self,
        *,
        down_axis: Iterable[float] = (0.0, 0.0, -1.0),
        forward_axis: Iterable[float] = (0.0, 1.0, 0.0),
        lateral_axis: Iterable[float] = (1.0, 0.0, 0.0),
        rest_threshold_deg: float = 8.0,
        dominance_ratio: float = 1.2,
    ) -> None:
        self._down = _unit_vector(down_axis, "down_axis")
        self._forward = _unit_vector(forward_axis, "forward_axis")
        self._lateral = _unit_vector(lateral_axis, "lateral_axis")
        if max(
            abs(float(np.dot(self._down, self._forward))),
            abs(float(np.dot(self._down, self._lateral))),
            abs(float(np.dot(self._forward, self._lateral))),
        ) > 0.15:
            raise ValueError("down, forward and lateral axes must be approximately orthogonal")
        if not 0.0 <= float(rest_threshold_deg) < 180.0:
            raise ValueError("rest_threshold_deg must be in [0, 180)")
        if float(dominance_ratio) < 1.0:
            raise ValueError("dominance_ratio must be at least 1")
        self.rest_threshold_deg = float(rest_threshold_deg)
        self.dominance_ratio = float(dominance_ratio)
        self._configured_forward = self._forward.copy()
        self._configured_lateral = self._lateral.copy()
        self._calibration: DualImuCalibration | None = None
        self._direction_calibration: DirectionCalibration | None = None

    @property
    def is_calibrated(self) -> bool:
        return self._calibration is not None

    @property
    def calibration(self) -> DualImuCalibration | None:
        return self._calibration

    @property
    def direction_calibration(self) -> DirectionCalibration | None:
        return self._direction_calibration

    def reset_calibration(self) -> None:
        self._calibration = None
        self._direction_calibration = None
        self._forward = self._configured_forward.copy()
        self._lateral = self._configured_lateral.copy()

    def calibrate(
        self,
        chest_quaternions: Iterable[Quaternion] | Quaternion,
        arm_quaternions: Iterable[Quaternion] | Quaternion,
    ) -> DualImuCalibration:
        """Calibrate from one or more synchronized, naturally-hanging samples."""
        chest = _samples(chest_quaternions)
        arm = _samples(arm_quaternions)
        if len(chest) != len(arm):
            raise ValueError("chest and arm calibration sample counts must match")
        if not chest:
            raise ValueError("at least one synchronized calibration sample is required")
        relative = [_relative(chest_q, arm_q) for chest_q, arm_q in zip(chest, arm)]
        result = DualImuCalibration(
            chest_reference=tuple(float(value) for value in _mean_quaternion(chest)),
            arm_reference=tuple(float(value) for value in _mean_quaternion(arm)),
            relative_reference=tuple(float(value) for value in _mean_quaternion(relative)),
            sample_count=len(chest),
        )
        self._calibration = result
        return result

    def calibrate_forward(
        self,
        chest_quaternions: Iterable[Quaternion] | Quaternion,
        arm_quaternions: Iterable[Quaternion] | Quaternion,
        *,
        minimum_raise_deg: float = 15.0,
    ) -> DirectionCalibration:
        """Learn the anatomical forward axis from a held forward-raised pose."""
        if self._calibration is None:
            raise RuntimeError("calibrate() must be called before calibrate_forward()")
        if not 0.0 < float(minimum_raise_deg) < 180.0:
            raise ValueError("minimum_raise_deg must be in (0, 180)")
        chest = _samples(chest_quaternions)
        arm = _samples(arm_quaternions)
        if len(chest) != len(arm):
            raise ValueError("chest and arm direction calibration sample counts must match")
        tangents: list[np.ndarray] = []
        magnitudes: list[float] = []
        for chest_q, arm_q in zip(chest, arm):
            pose = self.estimate(chest_q, arm_q)
            if pose.magnitude_deg < minimum_raise_deg:
                continue
            vector = np.asarray(pose.arm_vector, dtype=float)
            tangent = vector - self._down * float(np.dot(vector, self._down))
            norm = float(np.linalg.norm(tangent))
            if norm > 1e-9:
                tangents.append(tangent / norm)
                magnitudes.append(pose.magnitude_deg)
        if not tangents:
            raise ValueError(
                f"forward calibration requires a raise of at least {minimum_raise_deg:g} degrees"
            )
        forward = _unit_vector(np.mean(tangents, axis=0), "learned forward axis")
        lateral = _unit_vector(np.cross(self._down, forward), "learned lateral axis")
        self._forward = forward
        self._lateral = lateral
        result = DirectionCalibration(
            forward_axis=tuple(float(value) for value in forward),
            lateral_axis=tuple(float(value) for value in lateral),
            representative_magnitude_deg=float(np.median(magnitudes)),
            sample_count=len(tangents),
        )
        self._direction_calibration = result
        return result

    def estimate(self, chest_quaternion: Quaternion, arm_quaternion: Quaternion) -> ArmRaiseEstimate:
        """Return the current direction and arm-raise magnitude in degrees."""
        if self._calibration is None:
            raise RuntimeError("calibrate() must be called before estimate()")
        current_relative = _relative(chest_quaternion, arm_quaternion)
        delta = _multiply(current_relative, _conjugate(self._calibration.relative_reference))
        vector = _rotate(delta, self._down)
        vector /= max(float(np.linalg.norm(vector)), 1e-12)
        forward = float(np.dot(vector, self._forward))
        lateral = float(np.dot(vector, self._lateral))
        down = float(np.clip(np.dot(vector, self._down), -1.0, 1.0))
        magnitude = math.degrees(math.atan2(math.hypot(forward, lateral), down))
        plane = math.degrees(math.atan2(lateral, forward))

        if magnitude < self.rest_threshold_deg:
            direction, confidence = "Rest", 1.0
        else:
            forward_abs, lateral_abs = abs(forward), abs(lateral)
            dominant, secondary = max(forward_abs, lateral_abs), min(forward_abs, lateral_abs)
            confidence = float(np.clip((dominant - secondary) / max(dominant, 1e-12), 0.0, 1.0))
            if forward_abs >= self.dominance_ratio * lateral_abs:
                direction = "Forward" if forward >= 0.0 else "Backward"
            elif lateral_abs >= self.dominance_ratio * forward_abs:
                direction = "Lateral"
            else:
                direction = "Transition"

        return ArmRaiseEstimate(
            direction=direction,
            magnitude_deg=float(magnitude),
            plane_deg=float(plane),
            confidence=confidence,
            forward_component=forward,
            lateral_component=lateral,
            arm_vector=tuple(float(value) for value in vector),
        )

    update = estimate
